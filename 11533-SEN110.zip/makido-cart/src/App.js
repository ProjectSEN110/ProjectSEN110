import React, { useState } from "react";
import ProductList from "./components/ProductList";
import Cart from "./components/Cart";
import Checkout from "./components/Checkout";
import { CartProvider } from "./context/CartContext";
import "./App.css";

function App() {
  const [darkMode, setDarkMode] = useState(false);

  const toggleDarkMode = () => setDarkMode((prev) => !prev);

  return (
    <CartProvider>
      <div className={`app ${darkMode ? "dark" : "light"}`}>
        <header className="header">
          {/* Centered and colored Makido Store text */}
          <h1 className="store-title">Makido Store 🛒</h1>

          <button className="toggle-btn" onClick={toggleDarkMode}>
            {darkMode ? "🌙" : "☀️"}
          </button>
        </header>

        <main className="main-content">
          <section className="product-list">
            <ProductList />
          </section>

          <aside className="cart-section">
            <Cart />
            <Checkout />
          </aside>
        </main>

        <footer className="footer">
          &copy; {new Date().getFullYear()} Makido Store. All rights reserved.
        </footer>
      </div>
    </CartProvider>
  );
}

export default App;
