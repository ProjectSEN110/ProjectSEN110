import React, { useState } from "react";

const AdminPanel = ({ onAddProduct }) => {
  const [name, setName] = useState("");
  const [price, setPrice] = useState("");

  const handleAdd = () => {
    if (!name || !price) return alert("Fill all fields!");
    onAddProduct({ id: Date.now(), name, price: parseInt(price) });
    setName("");
    setPrice("");
  };

  return (
    <div style={{ marginTop: "30px" }}>
      <h3>🛠️ Admin Panel</h3>
      <input
        type="text"
        placeholder="Product name"
        value={name}
        onChange={(e) => setName(e.target.value)}
        style={{ padding: "5px", marginRight: "10px" }}
      />
      <input
        type="number"
        placeholder="Price (₦)"
        value={price}
        onChange={(e) => setPrice(e.target.value)}
        style={{ padding: "5px", marginRight: "10px" }}
      />
      <button onClick={handleAdd}>Add Product</button>
    </div>
  );
};

export default AdminPanel;
