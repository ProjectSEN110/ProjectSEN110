import React, { useContext } from "react";
import { CartContext } from "../context/CartContext";

const CartSummary = () => {
  const { cart } = useContext(CartContext);

  const total = cart.reduce((sum, item) => sum + item.price, 0);

  return (
    <div
      style={{
        background: "#222",
        color: "white",
        padding: "10px 20px",
        position: "sticky",
        top: 0,
        zIndex: 1000,
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        fontSize: "16px",
        fontWeight: "bold",
      }}
    >
      🛍️ Items in Cart: {cart.length}
      <span>Total: ₦{total}</span>
    </div>
  );
};

export default CartSummary;
