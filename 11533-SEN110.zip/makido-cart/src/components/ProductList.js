import React, { useContext, useState } from "react";
import { CartContext } from "../context/CartContext";
import AdminPanel from "./AdminPanel";

const initialProducts = [
  { id: 1, name: "Makido Shirt", price: 5000 },
  { id: 2, name: "Makido Shoes", price: 12000 },
  { id: 3, name: "Makido Cap", price: 3000 },
];

const ProductList = () => {
  const { addToCart } = useContext(CartContext);
  const [search, setSearch] = useState("");
  const [products, setProducts] = useState(initialProducts);

  const filteredProducts = products.filter((product) =>
    product.name.toLowerCase().includes(search.toLowerCase())
  );

  const handleAddProduct = (newProduct) => {
    setProducts((prev) => [...prev, newProduct]);
  };

  return (
    <div>
      <h2>Products</h2>

      <input
        type="text"
        placeholder="Search Makido Gear..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        style={{
          padding: "8px",
          width: "100%",
          marginBottom: "10px",
          borderRadius: "4px",
          border: "1px solid #ccc",
        }}
      />

      <ul>
        {filteredProducts.length === 0 ? (
          <p>No products found.</p>
        ) : (
          filteredProducts.map((product) => (
            <li key={product.id}>
              {product.name} - ₦{product.price}
              <button onClick={() => addToCart(product)} style={{ marginLeft: "10px" }}>
                Add
              </button>
            </li>
          ))
        )}
      </ul>

      <AdminPanel onAddProduct={handleAddProduct} />
    </div>
  );
};

export default ProductList;
