
import './App.css';

import React from 'react';
import './App.css'; // Assuming you might have a global App.css for basic styling
import ImageGenerator from './components/ImageGenerator/ImageGenerator';

function App() {
  return (
    <div className="App">
      
      <ImageGenerator />
    </div>
  );
}

export default App;