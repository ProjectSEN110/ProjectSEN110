import React, { useRef, useState } from 'react';
import './imagegenerator.css'; 
import aiimage from '../assets/aiimage.jpeg'; 

export const ImageGenerator = () => {
    // State variables
    const [imageUrl, setImageUrl] = useState(aiimage); 
    const inputRef = useRef(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState(null); 
    
    const generateImage = async () => {
        
        const prompt = inputRef.current.value.trim();

        
        if (!prompt) {
            setError("Please describe what you want to see!");
            return;
        }

        
        setIsLoading(true);
        setError(null); 
        setImageUrl(aiimage); 

        try {
            const response = await fetch(
                "https://api.openai.com/v1/images/generations",
                {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                       
                        Authorization: "Bearer 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",
                        
                    },
                    body: JSON.stringify({
                        prompt: prompt,
                        n: 1,
                        size: "512x512", 
                    }),
                }
            );

           
            if (!response.ok) {
                const errorData = await response.json();
                
                console.error("API Error Response:", errorData);
                
                throw new Error(errorData.error?.message || `API request failed with status: ${response.status}`);
            }

            const data = await response.json();
            
            if (data.data && data.data.length > 0 && data.data[0].url) {
                setImageUrl(data.data[0].url);
            } else {
                throw new Error("No image URL found in the API response.");
            }

        } catch (err) {
            console.error("Error during image generation:", err);
            setError(`Failed to generate image: ${err.message}. Please try again.`);
            setImageUrl(aiimage); 
        } finally {
            setIsLoading(false); 
        }
    };

    return (
        <div className="ai-image-generator">
            <div className="header">AI Image <span>Generator</span></div>

            
            <div className="img-loading">
                <div className="image">
                    <img src={imageUrl} alt="Generated AI Image" />
                </div>
                {isLoading && (
                    <div className="loading">
                        <div className="loading-bar-full"></div> 
                        <div className="loading-text">Generating image...</div>
                    </div>
                )}
                
                {error && <div className="error-message">{error}</div>}
            </div>

           
            <div className="search-box">
                <input
                    type="text"
                    ref={inputRef}   
                    className='search-input'
                    placeholder='Describe what you want to see (e.g., "A futuristic city at sunset")'
                    disabled={isLoading} 
                    onKeyDown={(e) => { 
                        if (e.key === 'Enter') {
                            generateImage();
                        }
                    }}
                />
                <div
                    className="generate-btn"
                    onClick={generateImage} 
                    disabled={isLoading} 
                >
                    {isLoading ? 'Generating...' : 'Generate'}
                </div>
            </div>
        </div>
    );
};

export default ImageGenerator; 