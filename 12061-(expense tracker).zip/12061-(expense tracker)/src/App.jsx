import { useState, useEffect } from "react";

import "./App.css";

const App = () => {
  const [transactions, setTransactions] = useState(
    JSON.parse(localStorage.getItem("transactions")) || []
  );
  const [amount, setAmount] = useState("");
  const [description, setDescription] = useState("");

  useEffect(() => {
    localStorage.setItem("transactions", JSON.stringify(transactions));
  }, [transactions]);

  const addTransaction = () => {
    if (!amount || !description) return;
    const newTransaction = { id: Date.now(), description, amount: parseFloat(amount) };
    setTransactions([...transactions, newTransaction]);
    setAmount("");
    setDescription("");
  };

  const deleteTransaction = (id) => {
    setTransactions(transactions.filter((txn) => txn.id !== id));
  };

  const totalAmount = transactions.reduce((acc, txn) => acc + txn.amount, 0).toFixed(2);

  return (
    <div className="container">
      <h2 className="header">Expense Tracker</h2>

      {/* Total Expenses & Summary */}
      <div className="summary">
        <h3>Total Expenses: ${totalAmount}</h3>
        <p>You have {transactions.length} transactions.</p>
      </div>

      {/* Expense Entry Form */}
      <div className="input-group">
        <input
          type="text"
          placeholder="Description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
        />
        <input
          type="number"
          placeholder="Amount"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
        />
        <button onClick={addTransaction}>Add Expense</button>
      </div>

      {/* Expense List */}
      <ul>
        {transactions.map((txn) => (
          <li key={txn.id}>
            {txn.description}: <span>${txn.amount.toFixed(2)}</span>
            <FaTrash className="delete-btn" onClick={() => deleteTransaction(txn.id)} />
          </li>
        ))}
      </ul>
    </div>
  );
};

export default App;
