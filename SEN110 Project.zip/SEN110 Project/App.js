import {useState} from 'react'
import Form from './components/Form'
import Admin from './components/Admin'
function App(){
  const [books, setBooks] = useState([])
  const [isAdmin, setIsAdmin] = useState(false)

  const handleAddBook =(book)=> {
  setBooks(prevBooks=>[...prevBooks, book])
  }
  return(
    <div className='p-4'>
      <h1 style={{textAlign:'center', backgroundColor:'blue',color:'white', padding:"20px", marginTop:'0'}}>Library Management System</h1>
      <button onClick={()=> setIsAdmin(prev => !prev)} className='mb-4 p-2 bg-blue-500 text-white rounded' style={{backgroundColor:'blue',padding:'10px', borderWidth:'0' ,borderRadius:'10px', color:'white', marginLeft:'10px',}}>
        Switch to {isAdmin ? 'User' : 'Admin'}View
      </button>
      {isAdmin ? (
        <Admin books= {books}/>
      ) :(
        <Form onAdd = {handleAddBook} books ={books}/>
      )}
    </div>
  )
}
export default App