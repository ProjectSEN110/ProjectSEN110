import {useState} from 'react'
const Form = ({ onAdd, books})=>{
    const [title,setTitle]= useState('')
    const [dateTaken, setDateTaken]= useState('')
    const [returnDate, setRetunDate]= useState('')

    const handleSubmit = (e)=> {
        e.preventDefault()
        if (!title.trim() || !dateTaken || !returnDate) 
            return
        onAdd({title:title.trim(), dateTaken, returnDate})
        setTitle('')
        setDateTaken('')
        setRetunDate('')
    }

    return(
        <div className='p-4 border rounded'>
            <form onSubmit={handleSubmit} className='form-section' style={{padding:'10px',marginRight:'10px'}}>
                <input 
                className='w-full p-2 border rounded'
                value={title}
                onChange={(e)=> setTitle(e.target.value)}
                placeholder='Book title'
                style={{Color:'red', borderColor:'red',borderWidth:'1px',padding:'10px', marginRight:'10px'}}
                />
                <input
                className='w-full p-2 border rounded'
                type='date'
                value={dateTaken}
                onChange= {(e)=> setDateTaken(e.target.value)}
                style={{Color:'red', borderColor:'red',borderWidth:'1px',padding:'10px', marginRight:'10px'}}
                />
                <input
                className='w-full p-2 border rounded'
                type='date'
                value={returnDate}
                onChange= {(e)=> setRetunDate(e.target.value)}
                style={{Color:'red', borderColor:'red',borderWidth:'1px',padding:'10px', marginRight:'10px'}}
                />
                <button
                 type='submit'
                 className='px-4 py-2 bg-green-500 text-white rounded'
                 style={{backgroundColor:'blue', border:'0px', borderRadius:'7px', paddingLeft:'15px',paddingRight:'15px',paddingTop:'10px',paddingBottom:'10px',color:'white',}}>
                    Add Book
                 </button>

            </form>
            <h2 className='mt-6 text-lg font-semibold' style={{textAlign:'center'}}>My Books</h2>
            <table style={{width:'100%',borderCollapse:'collapse',marginTop:'1rem'}}>
                <thead>
                    <tr>
                        <th style={{border:'1px solid blue', padding:'8px'}}>Title</th>
                        <th style={{border:'1px solid blue', padding:'8px'}}>Date Taken</th>
                        <th style={{border:'1px solid blue', padding:'8px'}}>Return Date</th>
                    </tr>
                </thead>
                <tbody>
                    {books.map((book,index)=>(
                        <tr key={index}>
                            <td style={{border:'1px solid black' , padding:'8px'}}>{book.title}</td>
                            <td style={{border:'1px solid black' , padding:'8px'}}>{book.dateTaken}</td>
                            <td style={{border:'1px solid black' , padding:'8px'}}>{book.returnDate}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>

    )
}
export default Form