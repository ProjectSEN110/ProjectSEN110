import React from 'react'
const Admin= ({books})=> {
    const list = books || []


    return(
    <div className='p-4 border rounded bg-gray-500'>
        <h2 className='text-lg font-semibold mb-4'>Admin View</h2>
        {list.length ===0 ?(
            <p style={{textAlign:'center'}}>No Books Borrowed</p>
        ):(
            <table style={{width:'100%', borderCollapse:'collapse', marginTop:'1rem'}}>
                <thead>
                    <tr>
                        <th style={{border:'1px solid blue', padding:'8px'}}>Title</th>
                        <th style={{border:'1px solid blue', padding:'8px'}}>Date Taken</th>
                        <th style={{border:'1px solid blue', padding:'8px'}}>Return Date</th>
                    </tr>
                </thead>
                <tbody>
                    {books.map((book,index)=>(
                        <tr key={index}>
                            <td style={{border:'1px solid black' , padding:'8px'}}>{book.title}</td>
                            <td style={{border:'1px solid black' , padding:'8px'}}>{book.dateTaken}</td>
                            <td style={{border:'1px solid black' , padding:'8px'}}>{book.returnDate}</td>
                        </tr>
                    ))}
                </tbody>
                
            </table>
        )}
    </div>
)
}
export default Admin