"use client"

import { useState } from "react"

const questions = [
  {
    question: "1. What will be the output of the following code snippet? const obj1={first: 20, second: 30, first: 50}",
    options: [
      "A. {first: 20,second: 30} ",
      "B. {first: 50, second: 30}",
      "C. {first: 20, second: 30, first: 50}",
      "D. Syntax Error",
    ],
    answer: "B. {first: 50, second: 30}",
  },
  {
    question: "2. What is JavaScript?",
    options: [
      "A. JavaScript is a scripting language used to make the website interactive",
      "B. JavaScript is an assembly language used to make the website interactive",
      "C. JavaScript is a compiled language used to make the website interactive",
      "D. None of the mentioned",
    ],
    answer: "A. JavaScript is a scripting language used to make the website interactive",
  },
  {
    question: "3. What should appear at the very end of your JavaScript? The script LANGUAGE JavaScript tag",
    options: ["A. The /script tag", "B. The script tag", "C. The END statement", "D. None of the above"],
    answer: "A. The /script tag",
  },
  {
    question: "4. What is the correct JavaScript syntax to write Hello World?",
    options: [
      "A. System.out.println(Hello World)",
      "B. println (Hello World)",
      "C. document.write(Hello World)",
      "D. response.write(Hello World)",
    ],
    answer: "C. document.write(Hello World)",
  },
]

export default function JavaScriptQuiz() {
  const [current, setCurrent] = useState(0)
  const [score, setScore] = useState(0)
  const [showResult, setShowResult] = useState(false)

  const handleAnswer = (option) => {
    if (option === questions[current].answer) {
      setScore(score + 1)
    }
    const next = current + 1
    if (next < questions.length) {
      setCurrent(next)
    } else {
      setShowResult(true)
    }
  }

  const resetQuiz = () => {
    setCurrent(0)
    setScore(0)
    setShowResult(false)
  }

  return (
    <>
      <style jsx>{`
        * {
          margin: 0;
          padding: 0;
          box-sizing: border-box;
        }
        
        body {
          font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          min-height: 100vh;
        }
        
        .container {
          min-height: 100vh;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          padding: 20px;
          display: flex;
          align-items: center;
          justify-content: center;
        }
        
        .quiz-wrapper {
          max-width: 800px;
          width: 100%;
        }
        
        .header {
          text-align: center;
          margin-bottom: 30px;
        }
        
        .title {
          color: white;
          font-size: 3rem;
          margin-bottom: 10px;
          text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
          font-weight: bold;
        }
        
        .subtitle {
          color: rgba(255,255,255,0.9);
          font-size: 1.2rem;
        }
        
        .card {
          background: white;
          border-radius: 20px;
          padding: 40px;
          box-shadow: 0 25px 50px rgba(0,0,0,0.15);
          backdrop-filter: blur(10px);
        }
        
        .progress-container {
          margin-bottom: 30px;
        }
        
        .progress-info {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 15px;
        }
        
        .progress-text {
          color: #666;
          font-weight: 500;
        }
        
        .score-badge {
          background: linear-gradient(135deg, #667eea, #764ba2);
          color: white;
          padding: 8px 20px;
          border-radius: 20px;
          font-weight: bold;
          box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
        }
        
        .progress-bar {
          width: 100%;
          height: 10px;
          background: #f0f0f0;
          border-radius: 10px;
          overflow: hidden;
        }
        
        .progress-fill {
          height: 100%;
          background: linear-gradient(90deg, #667eea, #764ba2);
          border-radius: 10px;
          transition: width 0.5s ease;
        }
        
        .question {
          color: #333;
          font-size: 1.4rem;
          line-height: 1.6;
          margin-bottom: 30px;
          font-weight: 500;
        }
        
        .options {
          display: grid;
          gap: 15px;
        }
        
        .option-btn {
          background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
          border: 2px solid #dee2e6;
          padding: 20px 25px;
          border-radius: 15px;
          cursor: pointer;
          font-size: 1.1rem;
          text-align: left;
          transition: all 0.3s ease;
          color: #333;
          font-weight: 500;
          position: relative;
          overflow: hidden;
        }
        
        .option-btn:hover {
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          color: white;
          transform: translateY(-3px);
          box-shadow: 0 15px 30px rgba(102, 126, 234, 0.4);
          border-color: #667eea;
        }
        
        .option-btn:active {
          transform: translateY(-1px);
        }
        
        .results-container {
          text-align: center;
        }
        
        .results-emoji {
          font-size: 5rem;
          margin-bottom: 20px;
          animation: bounce 1s ease-in-out;
        }
        
        @keyframes bounce {
          0%, 20%, 50%, 80%, 100% {
            transform: translateY(0);
          }
          40% {
            transform: translateY(-20px);
          }
          60% {
            transform: translateY(-10px);
          }
        }
        
        .results-title {
          color: #333;
          font-size: 2.5rem;
          margin-bottom: 20px;
          font-weight: bold;
        }
        
        .score-display {
          font-size: 4rem;
          font-weight: bold;
          margin-bottom: 20px;
          text-shadow: 2px 2px 4px rgba(0,0,0,0.1);
        }
        
        .score-excellent {
          color: #4CAF50;
        }
        
        .score-good {
          color: #FF9800;
        }
        
        .score-poor {
          color: #F44336;
        }
        
        .results-message {
          font-size: 1.3rem;
          color: #666;
          margin-bottom: 30px;
          font-weight: 500;
        }
        
        .reset-btn {
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          color: white;
          border: none;
          padding: 15px 40px;
          font-size: 1.2rem;
          border-radius: 30px;
          cursor: pointer;
          font-weight: bold;
          box-shadow: 0 10px 25px rgba(102, 126, 234, 0.4);
          transition: all 0.3s ease;
        }
        
        .reset-btn:hover {
          transform: translateY(-3px);
          box-shadow: 0 15px 35px rgba(102, 126, 234, 0.6);
        }
        
        .reset-btn:active {
          transform: translateY(-1px);
        }
        
        @media (max-width: 768px) {
          .title {
            font-size: 2.5rem;
          }
          
          .card {
            padding: 25px;
          }
          
          .question {
            font-size: 1.2rem;
          }
          
          .option-btn {
            padding: 15px 20px;
            font-size: 1rem;
          }
          
          .score-display {
            font-size: 3rem;
          }
        }
      `}</style>

      <div className="container">
        <div className="quiz-wrapper">
          <div className="header">
            <h1 className="title">🧠 JavaScript Quiz</h1>
            <p className="subtitle">Test your JavaScript knowledge</p>
          </div>

          {showResult ? (
            <div className="card">
              <div className="results-container">
                <div className="results-emoji">🎉</div>
                <h2 className="results-title">Quiz Complete!</h2>
                <div
                  className={`score-display ${score >= 3 ? "score-excellent" : score >= 2 ? "score-good" : "score-poor"}`}
                >
                  {score}/{questions.length}
                </div>
                <p className="results-message">
                  {score === questions.length
                    ? "Perfect Score! Amazing! 🌟"
                    : score >= 3
                      ? "Great Job! Well done! 👍"
                      : score >= 2
                        ? "Good Effort! Keep it up! 📚"
                        : "Keep Practicing! You'll get better! 💪"}
                </p>
                <button className="reset-btn" onClick={resetQuiz}>
                  🔄 Take Quiz Again
                </button>
              </div>
            </div>
          ) : (
            <div className="card">
              <div className="progress-container">
                <div className="progress-info">
                  <span className="progress-text">
                    Question {current + 1} of {questions.length}
                  </span>
                  <span className="score-badge">Score: {score}</span>
                </div>
                <div className="progress-bar">
                  <div
                    className="progress-fill"
                    style={{ width: `${((current + 1) / questions.length) * 100}%` }}
                  ></div>
                </div>
              </div>

              <h3 className="question">{questions[current].question}</h3>

              <div className="options">
                {questions[current].options.map((opt, index) => (
                  <button key={index} onClick={() => handleAnswer(opt)} className="option-btn">
                    {opt}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  )
}
