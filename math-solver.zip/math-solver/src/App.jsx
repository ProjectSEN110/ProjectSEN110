import React, { useState } from 'react';

const MathSolver = () => {
  const [n, setN] = useState('');
  const [r, setR] = useState('');
  const [operation, setOperation] = useState('permutation');
  const [result, setResult] = useState('');

  const factorial = (num) => {
    if (num < 0) return 0;
    if (num === 0 || num === 1) return 1;
    let result = 1;
    for (let i = 2; i <= num; i++) {
      result *= i;
    }
    return result;
  };

  const calculate = () => {
    const numN = parseInt(n);
    const numR = parseInt(r);

    if (isNaN(numN) || isNaN(numR) || numN < numR) {
      setResult(' Please enter valid values where n ≥ r.');
      return;
    }

    if (operation === 'permutation') {
      setResult(` Permutation (nPr) = ${factorial(numN) / factorial(numN - numR)}`);
    } else if (operation === 'combination') {
      setResult(` Combination (nCr) = ${factorial(numN) / (factorial(numR) * factorial(numN - numR))}`);
    }
  };



  return (
    <div style={pageStyle}>
      <div style={containerStyle}>
        <h2 style={{ textAlign: 'center' }}>Math Solver</h2>

        <label htmlFor="n" style={labelStyle}>Enter n:</label>
        <input
          type="number"
          id="n"
          value={n}
          onChange={(e) => setN(e.target.value)}
          style={inputStyle}
        />

        <label htmlFor="r" style={labelStyle}>Enter r:</label>
        <input
          type="number"
          id="r"
          value={r}
          onChange={(e) => setR(e.target.value)}
          style={inputStyle}
        />

        <label htmlFor="operation" style={labelStyle}>Choose Operation:</label>
        <select
          id="operation"
          value={operation}
          onChange={(e) => setOperation(e.target.value)}
          style={selectStyle}
        >
          <option value="permutation">Permutation (nPr)</option>
          <option value="combination">Combination (nCr)</option>
          
        </select>

        <button onClick={calculate} style={buttonStyle}>Calculate</button>

        {result && <div style={resultStyle}>{result}</div>}
      </div>
    </div>
  );
};
 
  const containerStyle = {
    maxWidth: '400px',
    margin: '50px auto',
    padding: '30px',
    borderRadius: '12px',
    boxShadow: '0 9px 30px rgba(0, 0, 0, 0.1)',
    backgroundColor: '#ffffff',
    fontFamily: 'Segoe UI, Tahoma, Geneva, Verdana, sans-serif',
    color: '#333',
  };

  const labelStyle = {
    display: 'block',
    marginBottom: '6px',
    marginTop: '12px',
    fontWeight: 'bold',
  };

  const inputStyle = {
    width: '100%',
    padding: '10px',
    borderRadius: '6px',
    border: '1px solid #ccc',
    marginBottom: '10px',
    fontSize: '16px',
  };

  const selectStyle = { ...inputStyle };

  const buttonStyle = {
    width: '100%',
    padding: '12px',
    backgroundColor: '#725EDE',
    color: 'white',
    border: 'none',
    borderRadius: '6px',
    fontSize: '16px',
    cursor: 'pointer',
    marginTop: '15px',
  };

  const resultStyle = {
    marginTop: '20px',
    backgroundColor: '#f0f8ff',
    padding: '10px',
    borderRadius: '6px',
    fontWeight: 'bold',
    color: '#2c3e50',
    textAlign: 'center',
  };
  const pageStyle = {
  backgroundColor: '#171616',
  minHeight: '',
  padding: '100px',
  margin: 'none'
 };

export default MathSolver;
