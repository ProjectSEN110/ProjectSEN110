import React, { useState } from 'react'; // Importing React and useState hook from react library

const MathSolver = () => { // Defining a functional React component named MathSolver
  const [n, setN] = useState(''); // State for user input 'n', initialized as empty string
  const [r, setR] = useState(''); // State for user input 'r', initialized as empty string
  const [operation, setOperation] = useState('permutation'); // State to track selected operation, default is 'permutation'
  const [result, setResult] = useState(''); // State to store the result of the computation

  const factorial = (num) => { // Helper function to calculate factorial
    if (num < 0) return 0; // Return 0 if number is negative
    if (num === 0 || num === 1) return 1; // Return 1 for 0! and 1!
    let result = 1; // Initialize result to 1
    for (let i = 2; i <= num; i++) { // Loop from 2 to num
      result *= i; // Multiply each value to get factorial
    }
    return result; // Return the computed factorial
  };

  const calculate = () => { // Function to perform calculation based on inputs and selected operation
    const numN = parseInt(n); // Convert string input 'n' to integer
    const numR = parseInt(r); // Convert string input 'r' to integer

    if (isNaN(numN) || isNaN(numR) || numN < numR) { // Check for invalid inputs or n < r
      setResult(' Please enter valid values where n ≥ r.'); // Show error message
      return; // Exit the function
    }

    if (operation === 'permutation') { // If selected operation is permutation
      setResult(` Permutation (nPr) = ${factorial(numN) / factorial(numN - numR)}`); // Compute nPr
    } else if (operation === 'combination') { // If selected operation is combination
      setResult(` Combination (nCr) = ${factorial(numN) / (factorial(numR) * factorial(numN - numR))}`); // Compute nCr
    }
  };
 
  const containerStyle = { // Style object for the inner container
    maxWidth: '400px', // Max width of the container
    margin: '50px auto', // Center align with margin
    padding: '30px', // Padding inside container
    borderRadius: '12px', // Rounded corners
    boxShadow: '0 9px 30px rgba(0, 0, 0, 0.1)', // Shadow effect
    backgroundColor: '#ffffff', // White background
    fontFamily: 'Segoe UI, Tahoma, Geneva, Verdana, sans-serif', // Font style
    color: '#333', // Text color
  };

  const labelStyle = { // Style object for labels
    display: 'block', // Make label a block element
    marginBottom: '6px', // Space below label
    marginTop: '12px', // Space above label
    fontWeight: 'bold', // Bold text
  };

  const inputStyle = { // Style object for input fields
    width: '100%', // Full width
    padding: '10px', // Padding inside input
    borderRadius: '6px', // Rounded corners
    border: '1px solid #ccc', // Light gray border
    marginBottom: '10px', // Space below input
    fontSize: '16px', // Font size
  };

  const selectStyle = { ...inputStyle }; // Dropdown uses same style as input

  const buttonStyle = { // Style object for the button
    width: '100%', // Full width
    padding: '12px', // Padding inside button
    backgroundColor: '#725EDE', // Button background color
    color: 'white', // Text color
    border: 'none', // No border
    borderRadius: '6px', // Rounded corners
    fontSize: '16px', // Font size
    cursor: 'pointer', // Cursor pointer on hover
    marginTop: '15px', // Space above button
  };

  const resultStyle = { // Style for the result box
    marginTop: '20px', // Space above result box
    backgroundColor: '#f0f8ff', // Light blue background
    padding: '10px', // Padding inside box
    borderRadius: '6px', // Rounded corners
    fontWeight: 'bold', // Bold text
    color: '#2c3e50', // Dark text color
    textAlign: 'center', // Center-aligned text
  };

  const pageStyle = { // Style for the outer page wrapper
    backgroundColor: '#171616', // Dark background color
    minHeight: '', // Minimum height not specified
    padding: '100px', // Padding around content
    margin: 'none' // No margin
  };

  return ( // JSX layout returned by the component
    <div style={pageStyle}> {/* Outer wrapper with dark background */}
      <div style={containerStyle}> {/* Centered white container */}
        <h2 style={{ textAlign: 'center' }}>Math Solver</h2> {/* Title */}

        <label htmlFor="n" style={labelStyle}>Enter n:</label> {/* Label for input n */}
        <input
          type="number" // Only numeric input allowed
          id="n" // ID for the input
          value={n} // Value comes from state
          onChange={(e) => setN(e.target.value)} // Update state on change
          style={inputStyle} // Apply styles
        />

        <label htmlFor="r" style={labelStyle}>Enter r:</label> {/* Label for input r */}
        <input
          type="number" // Only numeric input allowed
          id="r" // ID for the input
          value={r} // Value comes from state
          onChange={(e) => setR(e.target.value)} // Update state on change
          style={inputStyle} // Apply styles
        />

        <label htmlFor="operation" style={labelStyle}>Choose Operation:</label> {/* Label for dropdown */}
        <select
          id="operation" // ID for the dropdown
          value={operation} // Value from state
          onChange={(e) => setOperation(e.target.value)} // Update state on change
          style={selectStyle} // Apply styles
        >
          <option value="permutation">Permutation (nPr)</option> // Option for permutation
          <option value="combination">Combination (nCr)</option> // Option for combination
        </select>

        <button onClick={calculate} style={buttonStyle}>Calculate</button> {/* Button to trigger calculation */}

        {result && <div style={resultStyle}>{result}</div>} {/* Show result if available */}
      </div>
    </div>
  );
};

export default MathSolver; // Export the component for use elsewhere
