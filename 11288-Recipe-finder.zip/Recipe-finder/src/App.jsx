import React, { useState } from "react";

const API_KEY =  "d80c5a4054b3491686ecf7bbb7bba054";

function App() {
  const [query, setQuery] = useState("");
  const [recipes, setRecipes] = useState([]);
  const [selectedRecipe, setSelectedRecipe] = useState(null);

  const searchRecipes = async () => {
    try {
      const res = await fetch(
        `https://api.spoonacular.com/recipes/complexSearch?query=${query}&number=10&apiKey=${API_KEY}`
      );
      if (!res.ok) throw new Error(`Error: ${res.status}`);
      const data = await res.json();
      setRecipes(data.results);
    } catch (error) {
      console.error("Failed to fetch recipes:", error);
      alert("Failed to fetch recipes. Please try again later.");
    }
  };

  const fetchRecipeDetails = async (id) => {
    try {
      const res = await fetch(
        `https://api.spoonacular.com/recipes/${id}/information?includeNutrition=false&apiKey=${API_KEY}`
      );
      if (!res.ok) throw new Error(`Error: ${res.status}`);
      const data = await res.json();
      setSelectedRecipe(data);
    } catch (error) {
      console.error("Failed to fetch recipe details:", error);
      alert("Failed to fetch recipe details.");
    }
  };

  return (
    <div className="app-container">
      <h1>Recipe Finder</h1>
      <input
        type="text"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        placeholder="Search for recipes..."
      />
      <button onClick={searchRecipes}>
        Search
      </button>

      <div className="recipe-list">
        {recipes.map((recipe) => (
          <div
            key={recipe.id}
            onClick={() => fetchRecipeDetails(recipe.id)}
          >
            <h3>{recipe.title}</h3>
            <img
              src={recipe.image}
              alt={recipe.title}
            />
          </div>
        ))}
      </div>

      {selectedRecipe && (
        <div className="recipe-details">
          <h2>Ingredients for: {selectedRecipe.title}</h2>
          <ul>
            {selectedRecipe.extendedIngredients.map((ing) => (
              <li key={ing.id}>
                {ing.original}['
                ']
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}

export default App;
