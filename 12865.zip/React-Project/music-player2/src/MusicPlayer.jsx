import React, { useState, useRef, useEffect } from 'react';
import './MusicPlayer.css';



const MusicPlayer = () => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTrack, setCurrentTrack] = useState(0);
  const audioRef = useRef(null);

  
  const tracks = [
    { title: 'Swimming', src: '/Flawed Mangoes Swimming.mp3' },
    { title: 'Dramamine', src: '/Flawed Mangoes Dramamine.mp3' },
    { title: 'The Beginning', src: '/Flawed Mangoes The Beginning.mp3' }
  ];

  const handlePlayPause = async () => {
    try{
    if (isPlaying) {
      await audioRef.current.pause();
    } else {
      await audioRef.current.play();
    }
    setIsPlaying(!isPlaying);
  }catch (error){
    console.error("Audio error:", error);
  }
  }; 
  
  const changeTrack = async (newTrack) => {
    try{
      if (isPlaying){
        await audioRef.current.pause();
      }

      setCurrentTrack(newTrack);

      audioRef.current.src = tracks[newTrack].src;

      if (isPlaying){
        await audioRef.current.pause();
      }  
    }catch (error){
      console.error("Track change error:", error);
    }
    };
  
  const handleNextTrack = () => {
    setCurrentTrack((prev) => (prev + 1) % tracks.length);
    if (isPlaying) {
      audioRef.current.play();
    }
  };

  const handlePreviousTrack = () => {
    setCurrentTrack((prev) => (prev - 1 + tracks.length) % tracks.length);
    if (isPlaying) {
      audioRef.current.play();
    }
  };
  
  const handleTrackEnd = (trackIndex) => {
    const wasPlaying = isPlaying;
    if (wasPlaying){
        audioRef.current.pause();
    }
setCurrentTrack(trackIndex);
setIsPlaying(false);


if (wasPlaying){
    setTimeout(() => {
        audioRef.current.play();
        setIsPlaying(true);
    }, 0);
}
  };

  useEffect(() => {
    const audio = audioRef.current;
    audio.load(); 
    if (isPlaying) {
      audio.play();
    }
  }, [currentTrack]);

  return (
    <div className= 'music-player'>
      <h1>Music Player</h1>
      <hr/>

      <div className="track-info">
        <h2>{tracks[currentTrack].title}</h2>
      </div>

      <div className="player-controls">
        <button onClick={handlePreviousTrack}>Previous</button>
        <button onClick={handlePlayPause}>
          {isPlaying ? 'Pause' : 'Play'}
        </button>
        <button onClick={handleNextTrack}>Next</button>
      </div>
      
      <audio
        ref={audioRef}
        src={tracks[currentTrack].src}
        onEnded={handleTrackEnd}
      />
    </div>
  );
};

export default MusicPlayer;
