import { useState } from 'react'

function App() {
  const [firstNumber, setFirstNumber] = useState('')
  const [secondNumber, setSecondNumber] = useState('')
  const [result, setResult] = useState('')

  const handleAddition = () => {
    const sum = parseFloat(firstNumber) + parseFloat(secondNumber)
    setResult(sum)
  }

  const handleSubtraction = () => {
    const difference = parseFloat(firstNumber) - parseFloat(secondNumber)
    setResult(difference)
  }

  const handleMultiplication = () => {
    const product = parseFloat(firstNumber) * parseFloat(secondNumber)
    setResult(product)
  }

  const handleDivision = () => {
    if (parseFloat(secondNumber) === 0) {
      setResult('Error: Cannot divide by zero')
      return
    }
    const quotient = parseFloat(firstNumber) / parseFloat(secondNumber)
    setResult(quotient)
  }

  const handleClear = () => {
    setFirstNumber('')
    setSecondNumber('')
    setResult('')
  }

  return (
    <div className="calculator-container">
      <h1>Calculator</h1>
      
      <div className="input-section">
        <div className="input-group">
          <label htmlFor="first-number">First Number:</label>
          <input
            id="first-number"
            type="number"
            value={firstNumber}
            onChange={(e) => setFirstNumber(e.target.value)}
            placeholder="Enter first number"
          />
        </div>
        
        <div className="input-group">
          <label htmlFor="second-number">Second Number:</label>
          <input
            id="second-number"
            type="number"
            value={secondNumber}
            onChange={(e) => setSecondNumber(e.target.value)}
            placeholder="Enter second number"
          />
        </div>
      </div>

      <div className="button-section">
        <button 
          onClick={handleAddition}
          disabled={!firstNumber || !secondNumber}
          className="operation-btn addition"
        >
          + Add
        </button>
        
        <button 
          onClick={handleSubtraction}
          disabled={!firstNumber || !secondNumber}
          className="operation-btn subtraction"
        >
          - Subtract
        </button>
        
        <button 
          onClick={handleMultiplication}
          disabled={!firstNumber || !secondNumber}
          className="operation-btn multiplication"
        >
          × Multiply
        </button>
        
        <button 
          onClick={handleDivision}
          disabled={!firstNumber || !secondNumber}
          className="operation-btn division"
        >
          ÷ Divide
        </button>
        
        <button 
          onClick={handleClear}
          className="clear-btn"
        >
          Clear
        </button>
      </div>

      <div className="result-section">
        <h2>Result:</h2>
        <div className="result-display">
          {result !== '' ? result : 'No calculation yet'}
        </div>
      </div>

      <style jsx>{`
        .calculator-container {
          max-width: 400px;
          margin: 2rem auto;
          padding: 2rem;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          border-radius: 20px;
          box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
          font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
          color: white;
        }

        h1 {
          text-align: center;
          margin-bottom: 2rem;
          font-size: 2.5rem;
          text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
        }

        .input-section {
          margin-bottom: 2rem;
        }

        .input-group {
          margin-bottom: 1rem;
        }

        label {
          display: block;
          margin-bottom: 0.5rem;
          font-weight: 600;
          font-size: 1.1rem;
        }

        input {
          width: 100%;
          padding: 0.75rem;
          border: none;
          border-radius: 10px;
          font-size: 1rem;
          background: rgba(255, 255, 255, 0.9);
          box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.1);
          transition: all 0.3s ease;
        }

        input:focus {
          outline: none;
          background: white;
          box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.1), 0 0 0 3px rgba(255, 255, 255, 0.3);
        }

        .button-section {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 1rem;
          margin-bottom: 2rem;
        }

        .operation-btn {
          padding: 1rem;
          border: none;
          border-radius: 10px;
          font-size: 1.1rem;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.3s ease;
          background: rgba(255, 255, 255, 0.9);
          color: #333;
          box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        .operation-btn:hover:not(:disabled) {
          transform: translateY(-2px);
          box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3);
        }

        .operation-btn:active:not(:disabled) {
          transform: translateY(0);
        }

        .operation-btn:disabled {
          opacity: 0.5;
          cursor: not-allowed;
        }

        .addition { background: linear-gradient(135deg, #84fab0 0%, #8fd3f4 100%); }
        .subtraction { background: linear-gradient(135deg, #ffecd2 0%, #fcb69f 100%); }
        .multiplication { background: linear-gradient(135deg, #a8edea 0%, #fed6e3 100%); }
        .division { background: linear-gradient(135deg, #fad0c4 0%, #ffd1ff 100%); }

        .clear-btn {
          grid-column: 1 / -1;
          padding: 1rem;
          border: none;
          border-radius: 10px;
          font-size: 1.1rem;
          font-weight: 600;
          cursor: pointer;
          background: linear-gradient(135deg, #ff9a9e 0%, #fecfef 100%);
          color: #333;
          box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
          transition: all 0.3s ease;
        }

        .clear-btn:hover {
          transform: translateY(-2px);
          box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3);
        }

        .result-section {
          text-align: center;
        }

        .result-section h2 {
          margin-bottom: 1rem;
          font-size: 1.5rem;
        }

        .result-display {
          background: rgba(255, 255, 255, 0.9);
          color: #333;
          padding: 1.5rem;
          border-radius: 10px;
          font-size: 1.5rem;
          font-weight: 600;
          min-height: 2rem;
          display: flex;
          align-items: center;
          justify-content: center;
          box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        body {
          margin: 0;
          padding: 0;
          background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
          min-height: 100vh;
        }
      `}</style>
    </div>
  )
}

export default App