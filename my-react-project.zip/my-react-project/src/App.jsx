import react, {useState} from "react";


const initialRecipes = [
  {
    Id: 1,
    title: 'Spaghetti Carbonara',
    ingredients: ['spaghetti','eggs','parmesan cheese','bacon'],
    instructions:'Cook pasta.Mix eggs with cheese. Combine with cooked bacon',
  },
  {
    Id: 2,
    title: 'Chicken stir fry',
    ingredients: ['chicken breast','vegetables','soy sauce','garlic'],
    instructions:'Stir-fry chicken and vegetables. Add sauce and garlic.',
  },
];

function App() {
  const [recipes, setRecipes] = useState(initialRecipes);
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);
  const [selectedRecipe, setSelectedRecipe] = useState(null);

  const addRecipe = (newRecipe) => {
    setRecipes([...recipes, { ...newRecipe, id: Date.now() }]);
};

const filteredRecipes = recipes.filter(recipe =>
  recipe.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
  recipe.ingredients.some(ingredient =>
    ingredient.toLowerCase().includes(searchQuery.toLowerCase())
  )
);

return (
  <div className="app">
    <header>
      <h1>Recipe Book</h1>
      <div className="controls">
        <input
          type="text"placeholder="Search recipes..."value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)}/>
        <button onClick={() => setShowAddForm(true)}>Add Recipe</button>
      </div>
    </header>

    {showAddForm && (
      <AddRecipeForm onAdd={addRecipe} onClose={() => setShowAddForm(false)} />
    )}

    {selectedRecipe ? (
      <RecipeDetail recipe={selectedRecipe} onClose={() => setSelectedRecipe(null)}/>
     ) : (
      <RecipeList recipes={filteredRecipes} onSelect={setSelectedRecipe} />
    )}
    </div>
);
}

function RecipeList({ recipes, onSelect }) {
  return (
    <div className="recipe-list">
      {recipes.map(recipe => (
        <div key={recipe.id} className="recipe-card" onClick={() => onSelect(recipe)}>
          <h3>{recipe.title}</h3>
          <ul>
            {recipe.ingredients.map((ingredient, index) => (
              <li key={index}>{ingredient}</li>
            ))}
          </ul>
        </div>
      ))}
    </div>
  );

}

function RecipeDetail({ recipe, onClose }) {
  return (
    <div className="recipe-detail">
      <button className="back-button" onClick={onClose}>
        ← Back
      </button>
      <h2>{recipe.title}</h2>
      <div className="section">
        <h3>Ingredients</h3>
        <ul>
          {recipe.ingredients.map((ingredient, index) => (
            <li key={index}>{ingredient}</li>
          ))}
        </ul>
      </div>
      <div className="section">
        <h3>Instructions</h3>
        <p>{recipe.instructions}</p>
      </div>

    </div>
  );
}

function AddRecipeForm({ onAdd, onClose }) {
  const [title, setTitle] = useState('');
  const [ingredients, setIngredients] = useState('');
  const [instructions, setInstructions] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    onAdd({
      title,
      ingredients: ingredients.split(',').map(i => i.trim()),
      instructions,
    });
    setTitle('');
    setIngredients('');

    setInstructions('');
    onClose();
  };

  return (
    <div className="add-form-overlay">
      <form className="add-form" onSubmit={handleSubmit}>
        <h2>Add New Recipe</h2>
        <label>
          Title:
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            required
          />
        </label>
        <label>
          Ingredients (comma-separated):
          <textarea

            value={ingredients}
            onChange={(e) => setIngredients(e.target.value)}
            required
          />
        </label>
        <label>
          Instructions:
          <textarea
            value={instructions}
            onChange={(e) => setInstructions(e.target.value)}
            required
          />
        </label>
        <div className="form-buttons">
          <button type="submit">Add Recipe</button>
          <button type="button" onClick={onClose}>
            Cancel
          </button>

        </div>
      </form>
    </div>
  );
}

export default App;

