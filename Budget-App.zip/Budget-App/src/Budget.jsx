import { useState } from "react";

function Budget() {

    const [availMoney, setAvailMoney] = useState(0);

    const [firstSavingName, setFirstSavingName] = useState("");
    const [secondSavingName, setSecondSavingName] = useState("");
    const [thirdSavingName, setThirdSavingName] = useState("");
    const [fourthSavingName, setFourthSavingName] = useState("");
    const [fifthSavingName, setFifthSavingName] = useState("");

    const [firstSavingMoney, setFirstSavingMoney] = useState(0);
    const [secondSavingMoney, setSecondSavingMoney] = useState(0);
    const [thirdSavingMoney, setThirdSavingMoney] = useState(0);
    const [fourthSavingMoney, setFourthSavingMoney] = useState(0);
    const [fifthSavingMoney, setFifthSavingMoney] = useState(0);

    const [remainingMoney, setRemainingMoney] = useState(0);
    const [isValid, setIsValid] = useState(false);

    const save = () => {
        const totalSaved =
            Number(firstSavingMoney) +
            Number(secondSavingMoney) +
            Number(thirdSavingMoney) +
            Number(fourthSavingMoney) +
            Number(fifthSavingMoney);

        if (totalSaved > availMoney) {
            alert("You don't have enough money");
            setIsValid(false); 
            return;
        }

        alert("Saved");
        setRemainingMoney(availMoney - totalSaved);
        setIsValid(true);
    };

    const totalSaved =
        Number(firstSavingMoney) +
        Number(secondSavingMoney) +
        Number(thirdSavingMoney) +
        Number(fourthSavingMoney) +
        Number(fifthSavingMoney);

    return (
        <>
            <div class="okay">
                <div>
                    <h2>Available Money</h2>
                    <input
                        type="number"
                        min="0"
                        placeholder="Available Money"
                        onChange={(e) => setAvailMoney(Number(e.target.value))}
                    />
                </div>
                <div class="cat">
                <div>
                    <input
                        type="text"
                        placeholder="First Saving Name"
                        onChange={(e) => setFirstSavingName(e.target.value)}
                    />
                    <input
                        type="number"
                        min="0"
                        placeholder="First Saving Money"
                        onChange={(e) => setFirstSavingMoney(Number(e.target.value))}
                    />
                </div>

                <div>
                    <input
                        type="text"
                        placeholder="Second Saving Name"
                        onChange={(e) => setSecondSavingName(e.target.value)}
                    />
                    <input
                        type="number"
                        min="0"
                        placeholder="Second Saving Money"
                        onChange={(e) => setSecondSavingMoney(Number(e.target.value))}
                    />
                </div>

                <div>
                    <input
                        type="text"
                        placeholder="Third Saving Name"
                        onChange={(e) => setThirdSavingName(e.target.value)}
                    />
                    <input
                        type="number"
                        min="0"
                        placeholder="Third Saving Money"
                        onChange={(e) => setThirdSavingMoney(Number(e.target.value))}
                    />
                </div>

                <div>
                    <input
                        type="text"
                        placeholder="Fourth Saving Name"
                        onChange={(e) => setFourthSavingName(e.target.value)}
                    />
                    <input
                        type="number"
                        min="0"
                        placeholder="Fourth Saving Money"
                        onChange={(e) => setFourthSavingMoney(Number(e.target.value))}
                    />
                </div>

                <div>
                    <input
                        type="text"
                        placeholder="Fifth Saving Name"
                        onChange={(e) => setFifthSavingName(e.target.value)}
                    />
                    <input
                        type="number"
                        min="0"
                        placeholder="Fifth Saving Money"
                        onChange={(e) => setFifthSavingMoney(Number(e.target.value))}
                    />
                </div>

                <div class="mad">
                <button onClick={save}>Save</button> 
                </div>

            
            </div>
            </div>

            {isValid && (
                <>
                    <p>Available Money: {availMoney}</p>
                    <p>Accounted Expenditure: {totalSaved}</p>
                    <p>Remaining Money: {remainingMoney}</p>
                    {firstSavingName && <p>{firstSavingName}: {firstSavingMoney}</p>}
                    {secondSavingName && <p>{secondSavingName}: {secondSavingMoney}</p>}
                    {thirdSavingName && <p>{thirdSavingName}: {thirdSavingMoney}</p>}
                    {fourthSavingName && <p>{fourthSavingName}: {fourthSavingMoney}</p>}
                    {fifthSavingName && <p>{fifthSavingName}: {fifthSavingMoney}</p>}
                </>
            )}
        </>
    );
}

export default Budget;
