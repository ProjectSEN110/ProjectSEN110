import React, { useState } from "react";
import "./App.css";

function App() {
  const [expenses, setExpenses] = useState([]);
  const [amount, setAmount] = useState("");
  const [desc, setDesc] = useState("");

  const handleAdd = () => {
    if (amount && desc) {
      setExpenses([...expenses, { amount: parseFloat(amount), desc }]);
      setAmount("");
      setDesc("");
    }
  };

  const handleDelete = (indexToDelete) => {
    const updated = expenses.filter((_, index) => index !== indexToDelete);
    setExpenses(updated);
  };

  const total = expenses.reduce((acc, expense) => acc + expense.amount, 0);

  return (
    <div className="App">
      <div className="emoji">💸</div>
      <h1>Expense Tracker</h1>
      <div className="input-group">
        <input
          type="text"
          placeholder="Description"
          value={desc}
          onChange={(e) => setDesc(e.target.value)}
        />
        <input
          type="number"
          placeholder="Amount"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
        />
        <button onClick={handleAdd}>Add</button>
      </div>
      <h2>Total: ${total.toFixed(2)}</h2>
      <ul className="expense-list">
        {expenses.map((exp, index) => (
          <li key={index}>
            <span>{exp.desc}</span>
            <span>${exp.amount.toFixed(2)}</span>
            <button className="delete-btn" onClick={() => handleDelete(index)}>✖</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;
