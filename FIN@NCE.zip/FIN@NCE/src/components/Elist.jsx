import React from 'react';
import Eitem from './Eitem';

function Elist({ expenses, onDelete }) {
  return (
    <div className="expense-list">
      {expenses.map(exp => (
        <Eitem key={exp.id} expense={exp} onDelete={onDelete} />
      ))}
    </div>
  );
}

export default Elist;
