import React from 'react';

function Eitem({ expense, onDelete }) {
  return (
    <div className="expense-item">
      <span>{expense.name}</span>
      <span>{parseFloat(expense.amount).toFixed(2)} Naira</span>
      <button onClick={() => onDelete(expense.id)}>❌</button>
    </div>
  );
}

export default Eitem;
