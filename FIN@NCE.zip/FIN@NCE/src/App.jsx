import React, { useState } from 'react';
import Eform from './components/Eform';
import Elist from './components/Elist';
import './App.css';

function App() {
  const [expenses, setExpenses] = useState([]);

  const addExpense = (expense) => {
    setExpenses([expense, ...expenses]);
  }; 

  const deleteExpense = (id) => {
    setExpenses(expenses.filter(exp => exp.id !== id));
  };

  const total = expenses.reduce((acc, curr) => acc + parseFloat(curr.amount), 0);

  return (
    <div className="app-container">
      <h1>FIN@NCE</h1>
      <Eform onAdd={addExpense} />
      <h2>Total Spent:{total.toFixed(2)} Naira</h2>
      <Elist expenses={expenses} onDelete={deleteExpense} />
    </div>
  );
}

export default App;
  