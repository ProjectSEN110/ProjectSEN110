export const questions = [
    {
        question: "What is a variable in programming?",
        options: [
            "A fixed value",
            "A container for storing data values",
            "A type of function",
            "An error message"
        ],
        answer: "A container for storing data values"
    },
    {
        question: "Which of the following is a valid variable name?",
        options: [
            "2value",
            "value_2",
            "value-2",
            "value 2"
        ],
        answer: "value_2"
    },
    {
        question: "What does 'if' statement do in programming?",
        options: [
            "Repeats code",
            "Stores data",
            "Makes decisions based on conditions",
            "Defines a function"
        ],
        answer: "Makes decisions based on conditions"
    },
    {
        question: "Which symbol is used for single-line comments in JavaScript?",
        options: [
            "<!--",
            "//",
            "/*",
            "#"
        ],
        answer: "//"
    },
    {
        question: "What is a function?",
        options: [
            "A loop",
            "A block of code designed to perform a task",
            "A variable",
            "An operator"
        ],
        answer: "A block of code designed to perform a task"
    },
    {
        question: "Which of these is a data type?",
        options: [
            "integer",
            "string",
            "boolean",
            "All of the above"
        ],
        answer: "All of the above"
    },
    {
        question: "What does 'loop' mean in programming?",
        options: [
            "To store data",
            "To repeat a block of code",
            "To define a variable",
            "To end a program"
        ],
        answer: "To repeat a block of code"
    },
    {
        question: "Which of the following is NOT a programming language?",
        options: [
            "Python",
            "Java",
            "HTML",
            "C++"
        ],
        answer: "HTML"
    }
]
