import { useState } from "react";
import QuestionCard from "./QuestionCard";
import { questions } from "./Question";

const Quiz = () => {
  const [current, setCurrent] = useState(0);
  const [score, setScore] = useState(0);
  const [isFinished, setIsFinished] = useState(false);

  const handleAnswer = (selected) => {
    if (selected === questions[current].answer) {
      setScore(score + 1);
    }

    const next = current + 1;
    if (next < questions.length) {
      setCurrent(next);
    } else {
      setIsFinished(true);
    }
  };

  return (
    <div className="quiz-container">
      {isFinished ? (
        <div>
          <h2>Quiz Complete!</h2>
          <p>Your score: {score} / {questions.length}</p>
        </div>
      ) : (
        <QuestionCard
          question={questions[current]?.question}
          options={questions[current]?.options}
          handleAnswer={handleAnswer}
        />
      )}
    </div>
  );
};

export default Quiz;

