import React, { useState } from 'react';
import './App.css';

function App() {
  const [city, setCity] = useState('');
  const [weather, setWeather] = useState(null);
  const [error, setError] = useState('');

  const API_KEY = '0352bca06badd9611636b584e1bd53e5'; 

  const fetchWeather = async () => {
    if (!city) return;

    try {
      const response = await fetch(
        https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${API_KEY}&units=metric
      );
      const data = await response.json();
      console.log(data);


      if (data.cod === 200) {
        setWeather(data);
        setError('');
      } else {
        setWeather(null);
        setError('City not found. Please try again.');
      }
    } catch (err) {
      setError('An error occurred. Please try again.');
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter') {
      fetchWeather();
    }
  };

  return (
    <div className="App">
      <h1>Weather App</h1>
      <p id='p'>NAME : Okwe Samson <br></br>MATRIC : 11218<br></br>COURSE: SEN110<sub>lab</sub></p>
      <input
        type="text"
        placeholder="Enter city name"
        value={city}
        onChange={(e) => setCity(e.target.value)}
        onKeyPress={handleKeyPress}
      />
      <button onClick={fetchWeather}>Get Weather</button>

      {error && <p className="error">{error}</p>}

      {weather && (
        <div className="weather-info">
          <h2>{weather.name}, {weather.sys.country}</h2><br></br><br></br>
          <p>{weather.weather[0].description}</p><br></br>
          <p>Temperature: {weather.main.temp} °C</p><br></br>
          <p>Feels like: {weather.main.feels_like} °C</p><br></br>
          <p>Humidity: {weather.main.humidity}%</p><br></br>
        </div>
      )}
    </div>
  );
}

export default