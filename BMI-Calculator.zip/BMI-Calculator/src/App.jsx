import React, { useState } from "react";

export default function BMICalculator() {
  const [weight, setWeight] = useState("");
  const [height, setHeight] = useState("");
  const [bmi, setBMI] = useState(null);
  const [category, setCategory] = useState("");

  const calculateBMI = () => {
    if (weight && height) {
      const heightInMeters = height / 100;
      const bmiValue = (weight / (heightInMeters * heightInMeters)).toFixed(2);
      setBMI(bmiValue);

      let categoryMessage = "";
      if (bmiValue < 18.5 ) {
        categoryMessage = "Underweight";
      } else if (bmiValue < 24.9 ) {
        categoryMessage = "Normal weight";
      } else if (bmiValue < 29.9) {
        categoryMessage = "Overweight";
      } else {
        categoryMessage = "Obese";
      }

      setCategory(categoryMessage);
    }
  };

  return (
    <div style={{ maxWidth: "400px", marginLeft: "500px", padding: "20px", textAlign: "center", border: "1px solid #ccc", borderRadius: "10px", display: "flex", flexDirection: "column", gap: "20px"}}>
      <h2>BMI Calculator</h2>
      <div style={{ marginBottom: "10px" }}>
        <input
          type="number"
          placeholder="Weight in kg"
          value={weight}
          onChange={(e) => setWeight(e.target.value)}
          style={{ padding: "10px", width: "90%" }}
        />
      </div>
      <div style={{ marginBottom: "10px" }}>
        <input
          type="number"
          placeholder="Height in cm"
          value={height}
          onChange={(e) => setHeight(e.target.value)}
          style={{ padding: "10px", width: "90%" }}
        />
      </div>
      <button onClick={calculateBMI} style={{ padding: "10px 20px", cursor: "pointer" }}>Calculate</button>

      {bmi && (
        <div style={{ marginTop: "20px" }}>
          <h3>Your BMI: {bmi}</h3>
          <p>Status: <strong>{category}</strong></p>
        </div>
      )}
    </div>
  );
}