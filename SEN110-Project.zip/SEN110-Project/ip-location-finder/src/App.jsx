import React from 'react';

import MapComponent from './components/map';

function App() {
  return (
    <div>
      <h1 style={{ textAlign: 'center', padding: '1rem' }}> IP Location  Finder</h1>
      <MapComponent />
    </div>
  );
}

export default App;

