
import React, { useState } from 'react';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
});

const Api_key = 'd9b4751ba83a5f'; 

function MapComponent (){
  const [ip, setIp] = useState('');
  const [location, setLocation] = useState();

  async  function getLocation(){
    try {
      const res = await fetch(`https://ipinfo.io/${ip}?token=${Api_key}`);
      if(!res.ok){
        throw new Error('Failed to fetch locaion')
      }
      const data = await res.json();
      const [lat, lon] = data.loc.split(',').map(Number);

      setLocation({
        lat,
        lon,
        city: data.city,
        region: data.region,
        country: data.country,
        ip: data.ip,
      });
    } catch (error) {
      console.error(error);
      alert("Could'nt find location.");
    }
  };

  return (
    <div className='maps' >
      <h2> Find Location</h2>
      <input
        type="text"
        placeholder="Enter IP address (e.g. 8.8.8.8)"
        value={ip}
        onChange={(e) => setIp(e.target.value)}
      />
      <button onClick={getLocation}>
        Find Location
      </button>

      {location && (
        <>
          <div className='map' >
            <p>IP: {location.ip}</p>
            <p>City: {location.city}</p>
            <p>Region: {location.region}</p>
            <p>Country: {location.country}</p>
          </div>

          <MapContainer
            center={[location.lat, location.lon]}
            zoom={13}
            scrollWheelZoom={true}
            style={{ height: '70vh', width: '100%', marginTop: '1rem' }}
          >
            <TileLayer
              attribution='&copy; OpenStreetMap contributors'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />
            <Marker position={[location.lat, location.lon]}>
              <Popup>
                IP: {location.ip} <br /> {location.city}, {location.country}
              </Popup>
            </Marker>
          </MapContainer>
        </>
      )}
    </div>
  );
}

export default MapComponent;















