
import DigitalClock from "./DigitalClock";
import React, { useState } from 'react';

function App() {
   const [showClock, setShowClock] = useState(false);

   return (
      <>
      <div>
         {showClock ? <DigitalClock /> : <h1 className="opps"> My Clock App</h1>}
         <button onClick={() => setShowClock(!showClock)} className="btn">
            {showClock ? "Hide Clock" : "Show Clock"}
         </button>
      </div>  
      </>
    );
  };
export default App;
